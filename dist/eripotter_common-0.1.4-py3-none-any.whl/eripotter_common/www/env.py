# OpenAI
OPENAI_API_KEY = "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"

# Database URLs
DATABASE_URL = "postgresql://postgres:liyjJKKLWfrWOMFvdgPsWpJvcFdBUsks@switchyard.proxy.rlwy.net:38891/railway?sslmode=require"
ASYNC_DATABASE_URL = "postgresql+asyncpg://postgres:liyjJKKLWfrWOMFvdgPsWpJvcFdBUsks@switchyard.proxy.rlwy.net:38891/railway?sslmode=require"
